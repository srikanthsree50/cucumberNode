class Person {
moveTo(distance) {

}
shout(message){

}
messagesHeard(){
    return ["free bagel's at sean's"]
}
}

module.exports = Person