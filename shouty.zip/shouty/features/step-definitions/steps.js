const { Given , When , Then } = require('@cucumber/cucumber');
const Person  = require('../../src/shouty')
const { assertThat , is} = require('hamjest')

         Given('lucy is located {int}mts from range', function (distance) {
         
        // this.network = new Network()
            this.lucy = new Person()
           this.sean = new Person()
           this.lucy.moveTo(distance)
         });

         When('sean shouts {string}', function (message) {
             this.sean.shout(message);
             this.message= message
         });

         Then('lucy hears seans message', function () {
           assertThat(this.lucy.messagesHeard(),is([this.message]))
         });
